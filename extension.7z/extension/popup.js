document.getElementById("searchBtn").addEventListener("click", async () => {
    const query = document.getElementById("searchInput").value.trim();
    const results = document.getElementById("results");
    results.innerHTML = "";
  
    if (!query) return;
  
    const apiKey = "bcc3ad2";
    const res = await fetch(`https://www.omdbapi.com/?apikey=${apiKey}&s=${query}`);
    const data = await res.json();
  
    if (!data.Search) {
      results.innerHTML = `<p>No results found.</p>`;
      return;
    }
  
    // Create result cards
    data.Search.slice(0, 5).forEach(async (movie) => {
      const detailRes = await fetch(`https://www.omdbapi.com/?apikey=${apiKey}&i=${movie.imdbID}`);
      const detail = await detailRes.json();
  
      const imdbLink = `https://www.imdb.com/title/${detail.imdbID}`;
  
      // Add clickable result card
      const card = document.createElement("div");
      card.classList.add("card");
      card.style.cursor = "pointer";
  
      // Set content inside the card
      card.innerHTML = `
        <strong>${detail.Title} (${detail.Year})</strong><br>
        <b>Rating:</b> ${detail.imdbRating}<br>
        <b>Genre:</b> ${detail.Genre}<br>
        <b>Director:</b> ${detail.Director}<br>
        <b>Cast:</b> ${detail.Actors}<br>
        <p>${detail.Plot}</p>
      `;
  
      // Make the card clickable and open IMDb link in a new tab
      card.addEventListener("click", () => {
        window.open(imdbLink, "_blank");
      });
  
      // Append the card to the results section
      results.appendChild(card);
    });
  });
  